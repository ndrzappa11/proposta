package API;

import java.sql.Date;

public class Login {

	private String Iduser;
	private String nome;
	private String cognome;
	private String email;
	private String pass;
	private Date nascita;
	private String telefono;
	private Date inserimento;
	
	
	
	public String getId() {
		return Iduser;
	}
	public void setId(String id) {
		this.Iduser = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPass() {
		return pass;
	}
	public void setPass(String pass) {
		this.pass = pass;
	}
	public Date getNascita() {
		return nascita;
	}
	public void setNascita(Date nascita) {
		this.nascita = nascita;
	}
	public String getTelefono() {
		return telefono;
	}
	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}
	public Date getInserimento() {
		return inserimento;
	}
	public void setInserimento(Date inserimento) {
		this.inserimento = inserimento;
	} 
	
	
}
